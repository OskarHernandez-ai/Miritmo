# Mi Ritmo — versión completa

Aplicación web gratuita y sin dependencias externas para organizar agenda, horario, recordatorios, sesiones de enfoque y estudio.

## Incluye
- Mi día: actividades con fecha, hora, prioridad, notas y estado.
- Horario semanal recurrente.
- Calendario mensual.
- Recordatorios.
- Temporizador de enfoque con descansos y registro de sesiones.
- Estudio: mazos, flashcards y cuestionarios automáticos de opción múltiple.
- IndexedDB como base de datos local del navegador.
- Exportar/importar respaldos JSON.
- Tema claro/oscuro/automático.
- PWA instalable y funcionamiento offline.
- Diseño responsivo para computadora y celular.

## Ejecutar
Por las restricciones de IndexedDB/PWA, conviene servir la carpeta por HTTP. Ejemplos:

### Python
python -m http.server 8080

### Node
npx serve .

Después abre http://localhost:8080 (o la URL que muestre el servidor).

## Publicar gratis
Puedes subir esta carpeta a GitHub Pages, Netlify, Cloudflare Pages o Vercel. No requiere backend.

## Base de datos
Los datos se guardan en IndexedDB en el navegador del usuario. Esto evita costos de servidor y funciona sin internet. Para sincronización entre varios dispositivos se necesitaría una base de datos remota y autenticación (por ejemplo Supabase/Firebase).

(() => {
  'use strict';

  const NAV = [
    ['day','☀','Mi día'],['schedule','▦','Horario'],['month','▤','Mes'],['reminders','✓','Recordatorios'],
    ['focus','◴','Enfoque'],['study','✦','Estudio'],['settings','⚙','Ajustes']
  ];
  const DAYS = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const DAYS_SHORT = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];
  const MONTHS = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
  const DB_STORES = ['activities','schedule','reminders','decks','cards','settings','focusSessions'];

  let db;
  let state = {
    view:'day', selectedDate:isoDate(new Date()), monthCursor:new Date(new Date().getFullYear(),new Date().getMonth(),1),
    focus:{mode:'focus', remaining:25*60,total:25*60,running:false,timer:null,startedAt:null},
    studyDeck:null, studyMode:null, studyIndex:0, flipped:false, quiz:null
  };
  let installPrompt = null;

  const $ = s => document.querySelector(s);
  const esc = s => String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  function isoDate(d){const x=new Date(d);return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`}
  function parseDate(s){const [y,m,d]=s.split('-').map(Number);return new Date(y,m-1,d)}
  function fmtDate(s, opts={weekday:'long',day:'numeric',month:'long'}){return parseDate(s).toLocaleDateString('es-MX',opts)}
  function timeFmt(t){if(!t)return '';const [h,m]=t.split(':').map(Number);return new Date(2000,0,1,h,m).toLocaleTimeString('es-MX',{hour:'numeric',minute:'2-digit'})}
  function cmpTime(a,b){return (a.time||'99:99').localeCompare(b.time||'99:99')}

  function openDb(){
    return new Promise((resolve,reject)=>{
      const req=indexedDB.open('MiRitmoDB',3);
      req.onupgradeneeded=e=>{
        const d=e.target.result;
        for(const s of DB_STORES) if(!d.objectStoreNames.contains(s)) d.createObjectStore(s,{keyPath:'id'});
      };
      req.onsuccess=e=>resolve(e.target.result);req.onerror=()=>reject(req.error);
    });
  }
  function tx(store,mode='readonly'){return db.transaction(store,mode).objectStore(store)}
  function getAll(store){return new Promise((res,rej)=>{const r=tx(store).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})}
  function getOne(store,id){return new Promise((res,rej)=>{const r=tx(store).get(id);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
  function put(store,obj){return new Promise((res,rej)=>{const r=tx(store,'readwrite').put(obj);r.onsuccess=()=>res(obj);r.onerror=()=>rej(r.error)})}
  function del(store,id){return new Promise((res,rej)=>{const r=tx(store,'readwrite').delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
  function clearStore(store){return new Promise((res,rej)=>{const r=tx(store,'readwrite').clear();r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
  async function setting(key,fallback){const v=await getOne('settings',key);return v?.value ?? fallback}
  async function setSetting(key,value){await put('settings',{id:key,value})}

  async function init(){
    db=await openDb();
    buildNav(); bindGlobal(); await applyTheme(); await render();
    if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
  }
  function buildNav(){
    $('#mainNav').innerHTML=NAV.map(([id,icon,label])=>`<button class="nav-btn" data-nav="${id}"><span class="nav-icon">${icon}</span>${label}</button>`).join('');
  }
  function bindGlobal(){
    document.addEventListener('click',e=>{
      const nav=e.target.closest('[data-nav]');if(nav){state.view=nav.dataset.nav;state.studyMode=null;render();}
    });
    $('#primaryAction').addEventListener('click',primaryAction);
    window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('#installBtn').classList.remove('hidden')});
    $('#installBtn').addEventListener('click',async()=>{if(installPrompt){installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$('#installBtn').classList.add('hidden')}});
  }
  async function applyTheme(){
    const theme=await setting('theme','system');
    const resolved=theme==='system'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):theme;
    document.documentElement.dataset.theme=resolved;
  }
  function setHeader(title,eyebrow,action,visible=true){
    $('#pageTitle').textContent=title;$('#eyebrow').textContent=eyebrow;$('#primaryAction').textContent=action||'';$('#primaryAction').classList.toggle('hidden',!visible);
    document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.nav===state.view));
  }
  async function render(){
    const map={day:renderDay,schedule:renderSchedule,month:renderMonth,reminders:renderReminders,focus:renderFocus,study:renderStudy,settings:renderSettings};
    await (map[state.view]||renderDay)();
  }
  async function primaryAction(){
    if(state.view==='schedule') return scheduleModal();
    if(state.view==='reminders') return reminderModal();
    if(state.view==='study') return state.studyDeck ? cardModal(state.studyDeck) : deckModal();
    if(state.view==='month'||state.view==='day') return activityModal(null,state.selectedDate);
  }

  function empty(icon,title,text,button,label){return `<div class="empty"><div class="empty-icon">${icon}</div><h3>${esc(title)}</h3><p>${esc(text)}</p>${button?`<button class="btn primary" data-action="${button}">${esc(label)}</button>`:''}</div>`}

  async function renderDay(){
    setHeader('Mi día',fmtDate(state.selectedDate,{weekday:'long',day:'numeric',month:'long',year:'numeric'}),'＋ Nueva actividad');
    const acts=(await getAll('activities')).filter(a=>a.date===state.selectedDate).sort(cmpTime);
    const rems=(await getAll('reminders')).filter(r=>!r.done && r.date===state.selectedDate).sort(cmpTime);
    const sched=await getAll('schedule');
    const today=parseDate(state.selectedDate), dow=today.getDay();
    const dayBlocks=sched.filter(s=>Number(s.day)===dow).sort((a,b)=>a.start.localeCompare(b.start));
    const done=acts.filter(a=>a.done).length;
    $('#content').innerHTML=`
      <div class="card hero flat">
        <div><div class="eyebrow">HOY A TU RITMO</div><h2>${state.selectedDate===isoDate(new Date())?'Un día lleno de posibilidades.':esc(fmtDate(state.selectedDate,{weekday:'long',day:'numeric',month:'long'}))}</h2><p>Añade lo importante. Deja espacio para ti. Tu agenda funciona incluso sin internet.</p></div>
        <div class="hero-badge"><div><strong>${acts.length+rems.length}</strong><span>pendientes hoy</span></div></div>
      </div>
      <div class="grid four" style="margin-top:18px">
        <div class="card stat flat"><div class="stat-label">Actividades</div><div class="stat-value">${acts.length}</div><div class="stat-note">${done} completadas</div></div>
        <div class="card stat flat"><div class="stat-label">Horario</div><div class="stat-value">${dayBlocks.length}</div><div class="stat-note">bloques programados</div></div>
        <div class="card stat flat"><div class="stat-label">Recordatorios</div><div class="stat-value">${rems.length}</div><div class="stat-note">por completar</div></div>
        <div class="card stat flat"><div class="stat-label">Fecha</div><input id="dayPicker" type="date" value="${state.selectedDate}" style="margin-top:8px;width:100%;border:1px solid var(--line);border-radius:10px;padding:8px;background:var(--panel)"></div>
      </div>
      <div class="section-title"><div><h2>Tu agenda</h2><p>Actividades y recordatorios del día.</p></div></div>
      <div id="dayList" class="list">${renderDayItems(acts,rems)}</div>
      ${dayBlocks.length?`<div class="section-title"><div><h2>Tu horario de ${DAYS[dow].toLowerCase()}</h2><p>Bloques recurrentes de esta semana.</p></div></div><div class="list">${dayBlocks.map(b=>scheduleListItem(b)).join('')}</div>`:''}`;
    $('#dayPicker').onchange=e=>{state.selectedDate=e.target.value;render()};
    bindItemActions();
    $('#content').querySelector('[data-action="add-activity"]')?.addEventListener('click',()=>activityModal(null,state.selectedDate));
  }
  function renderDayItems(acts,rems){
    const items=[...acts.map(a=>({...a,_type:'activity'})),...rems.map(r=>({...r,_type:'reminder'}))].sort(cmpTime);
    if(!items.length)return empty('☀','Tu día está despejado','Una clase, una entrega o un rato para ti. Empieza con una actividad.','add-activity','＋ Agregar actividad');
    return items.map(i=>`<div class="list-item ${i.done?'done':''}" data-id="${i.id}" data-type="${i._type}">
      <button class="check ${i.done?'checked':''}" data-check aria-label="Marcar como completado">${i.done?'✓':''}</button>
      <div><h4>${esc(i.title)}${i.priority?`<span class="priority ${i.priority}">${priorityLabel(i.priority)}</span>`:''}</h4><p>${i.time?timeFmt(i.time):'Sin hora'}${i.notes?' · '+esc(i.notes):''}</p></div>
      <div class="item-actions"><button class="icon-btn" data-edit aria-label="Editar">✎</button><button class="icon-btn" data-delete aria-label="Eliminar">×</button></div>
    </div>`).join('')
  }
  function priorityLabel(p){return p==='high'?'Alta':p==='medium'?'Media':'Baja'}
  function scheduleListItem(b){return `<div class="list-item"><div class="time-chip">${timeFmt(b.start)}</div><div><h4>${esc(b.title)}</h4><p>${timeFmt(b.start)} – ${timeFmt(b.end)}${b.location?' · '+esc(b.location):''}</p></div><div class="item-actions"><button class="icon-btn" data-schedule-edit="${b.id}">✎</button></div></div>`}
  function bindItemActions(){
    $('#content').querySelectorAll('.list-item[data-id]').forEach(row=>{
      const {id,type}=row.dataset, store=type==='reminder'?'reminders':'activities';
      row.querySelector('[data-check]')?.addEventListener('click',async()=>{const o=await getOne(store,id);o.done=!o.done;await put(store,o);render()});
      row.querySelector('[data-edit]')?.addEventListener('click',async()=>type==='reminder'?reminderModal(await getOne(store,id)):activityModal(await getOne(store,id)));
      row.querySelector('[data-delete]')?.addEventListener('click',()=>confirmModal('Eliminar','¿Seguro que quieres eliminar este elemento?',async()=>{await del(store,id);toast('Eliminado');render()}));
    });
    $('#content').querySelectorAll('[data-schedule-edit]').forEach(b=>b.onclick=async()=>scheduleModal(await getOne('schedule',b.dataset.scheduleEdit)));
  }

  async function renderSchedule(){
    setHeader('Horario','Tu semana habitual','＋ Nuevo bloque');
    const blocks=await getAll('schedule');
    const hours=Array.from({length:15},(_,i)=>i+7);
    $('#content').innerHTML=`
      <div class="card flat"><div class="card-header"><div><h2 class="card-title">Horario semanal</h2><div class="subtle">Agrega clases, trabajo, gym o cualquier bloque que se repita.</div></div></div>
      ${blocks.length?`<div class="week-grid"><div class="week-head"></div>${[1,2,3,4,5,6,0].map(d=>`<div class="week-head">${DAYS_SHORT[d]}</div>`).join('')}${hours.map(h=>`<div class="week-time">${String(h).padStart(2,'0')}:00</div>${[1,2,3,4,5,6,0].map(d=>`<div class="week-slot">${blocks.filter(b=>Number(b.day)===d&&Number(b.start.split(':')[0])===h).map(b=>`<div class="schedule-block" data-schedule-edit="${b.id}"><b>${esc(b.title)}</b><span>${timeFmt(b.start)}–${timeFmt(b.end)}</span></div>`).join('')}</div>`).join('')}`).join('')}</div>`:empty('▦','Tu semana aún está libre','Añade tus clases, trabajo o actividades recurrentes para verlas aquí.','add-schedule','＋ Agregar bloque')}
      </div>`;
    $('#content').querySelector('[data-action="add-schedule"]')?.addEventListener('click',()=>scheduleModal());
    $('#content').querySelectorAll('[data-schedule-edit]').forEach(b=>b.onclick=async()=>scheduleModal(await getOne('schedule',b.dataset.scheduleEdit)));
  }

  async function renderMonth(){
    const c=state.monthCursor;setHeader('Mes',`${MONTHS[c.getMonth()]} ${c.getFullYear()}`,'＋ Nueva actividad');
    const acts=await getAll('activities'), rems=await getAll('reminders');
    const first=new Date(c.getFullYear(),c.getMonth(),1), start=new Date(first);start.setDate(1-((first.getDay()+6)%7));
    const cells=Array.from({length:42},(_,i)=>{const d=new Date(start);d.setDate(start.getDate()+i);return d});
    $('#content').innerHTML=`<div class="card flat"><div class="card-header"><div class="month-toolbar"><button class="icon-btn" id="prevMonth">‹</button><div class="month-name">${MONTHS[c.getMonth()].replace(/^./,x=>x.toUpperCase())} ${c.getFullYear()}</div><button class="icon-btn" id="nextMonth">›</button></div><button class="btn small" id="todayMonth">Hoy</button></div>
      <div class="calendar-head">${['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'].map(x=>`<div>${x}</div>`).join('')}</div>
      <div class="calendar-grid">${cells.map(d=>{const key=isoDate(d),events=[...acts.filter(a=>a.date===key),...rems.filter(r=>r.date===key)];return `<div class="calendar-cell ${d.getMonth()!==c.getMonth()?'other':''} ${key===isoDate(new Date())?'today':''}" data-date="${key}"><div class="day-num">${d.getDate()}</div>${events.slice(0,3).map(e=>`<div class="event-dot">${e.time?timeFmt(e.time)+' ':''}${esc(e.title)}</div>`).join('')}${events.length>3?`<div class="subtle">+${events.length-3}</div>`:''}</div>`}).join('')}</div></div>`;
    $('#prevMonth').onclick=()=>{state.monthCursor=new Date(c.getFullYear(),c.getMonth()-1,1);render()};$('#nextMonth').onclick=()=>{state.monthCursor=new Date(c.getFullYear(),c.getMonth()+1,1);render()};$('#todayMonth').onclick=()=>{const n=new Date();state.monthCursor=new Date(n.getFullYear(),n.getMonth(),1);state.selectedDate=isoDate(n);render()};
    $('#content').querySelectorAll('[data-date]').forEach(el=>el.onclick=()=>{state.selectedDate=el.dataset.date;state.view='day';render()});
  }

  async function renderReminders(){
    setHeader('Recordatorios','No dejes que se te pase','＋ Nuevo recordatorio');
    const rs=(await getAll('reminders')).sort((a,b)=>(a.done-b.done)||a.date.localeCompare(b.date)||cmpTime(a,b));
    const pending=rs.filter(r=>!r.done), completed=rs.filter(r=>r.done);
    $('#content').innerHTML=`<div class="grid three"><div class="card stat flat"><div class="stat-label">Pendientes</div><div class="stat-value">${pending.length}</div></div><div class="card stat flat"><div class="stat-label">Completados</div><div class="stat-value">${completed.length}</div></div><div class="card stat flat"><div class="stat-label">Próximos 7 días</div><div class="stat-value">${countNext7(pending)}</div></div></div>
      <div class="section-title"><div><h2>Pendientes</h2><p>Ordenados por fecha.</p></div></div><div class="list">${pending.length?pending.map(reminderRow).join(''):empty('✓','Todo al día','No tienes recordatorios pendientes.','add-reminder','＋ Crear recordatorio')}</div>
      ${completed.length?`<div class="section-title"><div><h2>Completados</h2></div></div><div class="list">${completed.map(reminderRow).join('')}</div>`:''}`;
    bindItemActions();$('#content').querySelector('[data-action="add-reminder"]')?.addEventListener('click',()=>reminderModal());
  }
  function reminderRow(r){return `<div class="list-item ${r.done?'done':''}" data-id="${r.id}" data-type="reminder"><button class="check ${r.done?'checked':''}" data-check>${r.done?'✓':''}</button><div><h4>${esc(r.title)}<span class="priority ${r.priority||'medium'}">${priorityLabel(r.priority||'medium')}</span></h4><p>${fmtDate(r.date,{day:'numeric',month:'short'})}${r.time?' · '+timeFmt(r.time):''}${r.notes?' · '+esc(r.notes):''}</p></div><div class="item-actions"><button class="icon-btn" data-edit>✎</button><button class="icon-btn" data-delete>×</button></div></div>`}
  function countNext7(rs){const t=new Date();t.setHours(0,0,0,0);const e=new Date(t);e.setDate(e.getDate()+7);return rs.filter(r=>{const d=parseDate(r.date);return d>=t&&d<=e}).length}

  async function renderFocus(){
    setHeader('Enfoque','Concéntrate en una cosa a la vez','',false);
    const sessions=await getAll('focusSessions'), today=sessions.filter(s=>s.date===isoDate(new Date()));
    const settings={focus:Number(await setting('focusMinutes',25)),short:Number(await setting('shortBreak',5)),long:Number(await setting('longBreak',15))};
    if(!state.focus.running && !state.focus.initialized){state.focus.remaining=settings.focus*60;state.focus.total=settings.focus*60;state.focus.initialized=true}
    const tasks=(await getAll('activities')).filter(a=>!a.done&&a.date===isoDate(new Date()));
    $('#content').innerHTML=`<div class="focus-wrap"><div class="card timer-card"><div class="mode-tabs"><button class="mode-tab ${state.focus.mode==='focus'?'active':''}" data-mode="focus">Enfoque</button><button class="mode-tab ${state.focus.mode==='short'?'active':''}" data-mode="short">Descanso</button><button class="mode-tab ${state.focus.mode==='long'?'active':''}" data-mode="long">Descanso largo</button></div><div id="timerRing" class="timer-ring"><div class="timer-content"><div id="timerTime" class="timer-time">${timerText(state.focus.remaining)}</div><div class="timer-label">${state.focus.mode==='focus'?'momento de concentrarte':'momento de descansar'}</div></div></div><div class="timer-actions"><button class="btn primary" id="timerToggle">${state.focus.running?'Pausar':'Empezar'}</button><button class="btn" id="timerReset">Reiniciar</button></div></div>
      <div class="grid"><div class="card"><div class="card-header"><h2 class="card-title">Sesiones de hoy</h2></div><div class="grid two"><div class="stat flat"><div class="stat-label">Completadas</div><div class="stat-value">${today.length}</div></div><div class="stat flat"><div class="stat-label">Minutos</div><div class="stat-value">${today.reduce((n,s)=>n+(s.minutes||0),0)}</div></div></div></div><div class="card"><div class="card-header"><h2 class="card-title">Para enfocarte hoy</h2></div>${tasks.length?`<div class="list">${tasks.slice(0,4).map(a=>`<div class="list-item"><div class="check"></div><div><h4>${esc(a.title)}</h4><p>${a.time?timeFmt(a.time):'Sin hora'}</p></div></div>`).join('')}</div>`:`<p class="subtle">No tienes actividades pendientes para hoy. Puedes iniciar una sesión libre.</p>`}</div></div></div>`;
    updateTimerUi();
    $('#content').querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>switchTimerMode(b.dataset.mode,settings));
    $('#timerToggle').onclick=toggleTimer;$('#timerReset').onclick=()=>resetTimer(settings);
  }
  function timerText(sec){return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`}
  function updateTimerUi(){const t=$('#timerTime'),ring=$('#timerRing'),btn=$('#timerToggle');if(t)t.textContent=timerText(state.focus.remaining);if(ring)ring.style.setProperty('--progress',`${100-(state.focus.remaining/state.focus.total*100)}%`);if(btn)btn.textContent=state.focus.running?'Pausar':'Empezar';document.title=`${timerText(state.focus.remaining)} · Mi Ritmo`}
  function switchTimerMode(mode,s){if(state.focus.timer)clearInterval(state.focus.timer);state.focus.running=false;state.focus.mode=mode;const min=mode==='focus'?s.focus:mode==='short'?s.short:s.long;state.focus.total=state.focus.remaining=min*60;render()}
  function toggleTimer(){if(state.focus.running){clearInterval(state.focus.timer);state.focus.running=false;updateTimerUi();return}state.focus.running=true;state.focus.timer=setInterval(async()=>{state.focus.remaining--;updateTimerUi();if(state.focus.remaining<=0){clearInterval(state.focus.timer);state.focus.running=false;if(state.focus.mode==='focus'){await put('focusSessions',{id:uid(),date:isoDate(new Date()),minutes:Math.round(state.focus.total/60),createdAt:Date.now()});toast('Sesión completada ✦');if(Notification.permission==='granted')new Notification('Mi Ritmo',{body:'¡Sesión de enfoque completada!'})}render()}},1000);updateTimerUi()}
  function resetTimer(s){if(state.focus.timer)clearInterval(state.focus.timer);state.focus.running=false;const min=state.focus.mode==='focus'?s.focus:state.focus.mode==='short'?s.short:s.long;state.focus.total=state.focus.remaining=min*60;updateTimerUi()}

  async function renderStudy(){
    setHeader('Estudio','Flashcards y cuestionarios',state.studyDeck?'＋ Nueva tarjeta':'＋ Nuevo mazo');
    const decks=await getAll('decks'), cards=await getAll('cards');
    if(state.studyMode==='flash') return renderFlashStudy(cards.filter(c=>c.deckId===state.studyDeck));
    if(state.studyMode==='quiz') return renderQuiz(cards.filter(c=>c.deckId===state.studyDeck));
    if(state.studyDeck){
      const deck=decks.find(d=>d.id===state.studyDeck);if(!deck){state.studyDeck=null;return renderStudy()}
      const deckCards=cards.filter(c=>c.deckId===deck.id);
      $('#content').innerHTML=`<div class="card hero flat"><div><button class="btn small ghost" id="backDecks">← Todos los mazos</button><div class="eyebrow" style="margin-top:16px">MAZO DE ESTUDIO</div><h2>${esc(deck.name)}</h2><p>${esc(deck.description||'Repasa tus conceptos y comprueba lo que aprendiste.')}</p></div><div class="hero-badge"><div><strong>${deckCards.length}</strong><span>tarjetas</span></div></div></div>
        <div class="grid two" style="margin-top:18px"><button class="card flat" id="startFlash" style="text-align:left;cursor:pointer"><div class="deck-icon">◫</div><h3 style="margin:10px 0 5px">Repasar flashcards</h3><p class="subtle">Voltea las tarjetas y avanza a tu ritmo.</p></button><button class="card flat" id="startQuiz" style="text-align:left;cursor:pointer"><div class="deck-icon">?</div><h3 style="margin:10px 0 5px">Hacer cuestionario</h3><p class="subtle">Genera preguntas de opción múltiple con tus tarjetas.</p></button></div>
        <div class="section-title"><div><h2>Tarjetas</h2><p>${deckCards.length} en este mazo</p></div><button class="btn small" id="editDeck">Editar mazo</button></div>
        ${deckCards.length?`<div class="list">${deckCards.map(c=>`<div class="list-item" data-card="${c.id}"><div class="time-chip">Q</div><div><h4>${esc(c.front)}</h4><p>${esc(c.back)}</p></div><div class="item-actions"><button class="icon-btn" data-card-edit>✎</button><button class="icon-btn" data-card-delete>×</button></div></div>`).join('')}</div>`:empty('✦','Agrega tu primera tarjeta','Escribe una pregunta o concepto al frente y la respuesta atrás.','add-card','＋ Nueva tarjeta')}`;
      $('#backDecks').onclick=()=>{state.studyDeck=null;render()};$('#editDeck').onclick=()=>deckModal(deck);$('#startFlash').onclick=()=>{if(!deckCards.length)return toast('Agrega al menos una tarjeta');state.studyMode='flash';state.studyIndex=0;state.flipped=false;render()};$('#startQuiz').onclick=()=>{if(deckCards.length<2)return toast('Necesitas al menos 2 tarjetas para el cuestionario');state.studyMode='quiz';state.quiz=null;render()};$('#content').querySelector('[data-action="add-card"]')?.addEventListener('click',()=>cardModal(deck.id));
      $('#content').querySelectorAll('[data-card]').forEach(row=>{const c=deckCards.find(x=>x.id===row.dataset.card);row.querySelector('[data-card-edit]').onclick=()=>cardModal(deck.id,c);row.querySelector('[data-card-delete]').onclick=()=>confirmModal('Eliminar tarjeta','Esta tarjeta se eliminará del mazo.',async()=>{await del('cards',c.id);render()})});
      return;
    }
    $('#content').innerHTML=`<div class="card hero flat"><div><div class="eyebrow">TU ESPACIO DE ESTUDIO</div><h2>Aprende con práctica activa.</h2><p>Crea mazos, conviértelos en flashcards y genera cuestionarios automáticamente. Todo se guarda en la base de datos local de tu navegador.</p></div><div class="hero-badge"><div><strong>${cards.length}</strong><span>tarjetas</span></div></div></div><div class="section-title"><div><h2>Tus mazos</h2><p>${decks.length} mazos creados.</p></div></div>${decks.length?`<div class="deck-grid">${decks.map(d=>{const n=cards.filter(c=>c.deckId===d.id).length;return `<div class="card deck flat" data-deck="${d.id}"><div class="deck-icon">${esc(d.icon||'✦')}</div><h3>${esc(d.name)}</h3><p>${esc(d.description||'Sin descripción')}</p><footer><span>${n} tarjetas</span><span>Abrir →</span></footer></div>`}).join('')}</div>`:empty('✦','Crea tu primer mazo','Puedes hacer uno para inglés, IA, bases de datos o cualquier materia.','add-deck','＋ Nuevo mazo')}`;
    $('#content').querySelectorAll('[data-deck]').forEach(d=>d.onclick=()=>{state.studyDeck=d.dataset.deck;render()});$('#content').querySelector('[data-action="add-deck"]')?.addEventListener('click',()=>deckModal());
  }
  async function renderFlashStudy(deckCards){
    setHeader('Repasar','Flashcards','',false);if(!deckCards.length){state.studyMode=null;return renderStudy()};
    const i=Math.min(state.studyIndex,deckCards.length-1),c=deckCards[i];
    $('#content').innerHTML=`<div class="study-stage"><button class="btn small ghost" id="exitStudy">← Volver al mazo</button><div style="max-width:720px;margin:20px auto 0"><div class="progress-bar"><div style="width:${((i+1)/deckCards.length)*100}%"></div></div><div class="subtle" style="margin-top:7px">Tarjeta ${i+1} de ${deckCards.length}</div></div><div class="flashcard ${state.flipped?'flipped':''}" id="flashcard"><div class="flashcard-inner"><div class="flash-side front"><div class="label">Pregunta / concepto</div><div class="text">${esc(c.front)}</div></div><div class="flash-side back"><div class="label">Respuesta</div><div class="text">${esc(c.back)}</div></div></div></div><p class="subtle">Haz clic en la tarjeta para voltearla.</p><div class="timer-actions"><button class="btn" id="prevCard" ${i===0?'disabled':''}>← Anterior</button><button class="btn primary" id="nextCard">${i===deckCards.length-1?'Terminar':'Siguiente →'}</button></div></div>`;
    $('#exitStudy').onclick=()=>{state.studyMode=null;render()};$('#flashcard').onclick=()=>{state.flipped=!state.flipped;$('#flashcard').classList.toggle('flipped',state.flipped)};$('#prevCard').onclick=()=>{if(i>0){state.studyIndex=i-1;state.flipped=false;render()}};$('#nextCard').onclick=()=>{if(i<deckCards.length-1){state.studyIndex=i+1;state.flipped=false;render()}else{toast('Repaso completado ✦');state.studyMode=null;render()}};
  }
  function shuffle(a){const x=[...a];for(let i=x.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[x[i],x[j]]=[x[j],x[i]]}return x}
  async function renderQuiz(deckCards){
    setHeader('Cuestionario','Ponte a prueba','',false);
    if(!state.quiz){const qs=shuffle(deckCards).slice(0,Math.min(10,deckCards.length)).map(c=>({card:c,options:shuffle([c.back,...shuffle(deckCards.filter(x=>x.id!==c.id)).slice(0,3).map(x=>x.back)]),answered:null}));state.quiz={index:0,score:0,questions:qs,finished:false}}
    const qz=state.quiz;if(qz.finished){$('#content').innerHTML=`<div class="card study-stage" style="max-width:680px;margin:auto;padding:44px"><div class="empty-icon">✦</div><h2>Cuestionario terminado</h2><div class="stat-value">${qz.score}/${qz.questions.length}</div><p class="subtle">${qz.score/qz.questions.length>=.8?'¡Excelente! Dominas muy bien este mazo.':qz.score/qz.questions.length>=.6?'Vas bien. Un repaso más puede ayudarte.':'Conviene volver a las flashcards y repetir el cuestionario.'}</p><div class="timer-actions" style="margin-top:22px"><button class="btn" id="quizBack">Volver al mazo</button><button class="btn primary" id="quizAgain">Repetir</button></div></div>`;$('#quizBack').onclick=()=>{state.studyMode=null;state.quiz=null;render()};$('#quizAgain').onclick=()=>{state.quiz=null;render()};return}
    const i=qz.index,q=qz.questions[i];
    $('#content').innerHTML=`<div style="max-width:760px;margin:auto"><button class="btn small ghost" id="quizExit">← Salir</button><div class="card" style="margin-top:18px"><div class="progress-bar"><div style="width:${((i+1)/qz.questions.length)*100}%"></div></div><div class="subtle" style="margin:10px 0 22px">Pregunta ${i+1} de ${qz.questions.length} · Puntaje ${qz.score}</div><h2 style="font-size:22px;margin-bottom:20px">${esc(q.card.front)}</h2><div id="quizOptions">${q.options.map((o,idx)=>`<button class="quiz-option ${q.answered!==null?(o===q.card.back?'correct':idx===q.answered?'wrong':''):''}" data-option="${idx}" ${q.answered!==null?'disabled':''}>${esc(o)}</button>`).join('')}</div>${q.answered!==null?`<div style="margin-top:18px;text-align:right"><button class="btn primary" id="quizNext">${i===qz.questions.length-1?'Ver resultado':'Siguiente →'}</button></div>`:''}</div></div>`;
    $('#quizExit').onclick=()=>{state.studyMode=null;state.quiz=null;render()};$('#content').querySelectorAll('[data-option]').forEach(b=>b.onclick=()=>{const idx=Number(b.dataset.option);q.answered=idx;if(q.options[idx]===q.card.back)qz.score++;render()});$('#quizNext')?.addEventListener('click',()=>{if(i===qz.questions.length-1)qz.finished=true;else qz.index++;render()});
  }

  async function renderSettings(){
    setHeader('Ajustes','Haz Mi Ritmo tuyo','',false);const theme=await setting('theme','system'),fm=await setting('focusMinutes',25),sb=await setting('shortBreak',5),lb=await setting('longBreak',15);
    const storesData=await Promise.all(['activities','schedule','reminders','decks','cards'].map(getAll));const count=storesData.reduce((n,a)=>n+a.length,0);
    $('#content').innerHTML=`<div class="grid two"><div class="card"><div class="card-header"><h2 class="card-title">Apariencia</h2></div><div class="settings-row"><div><h4>Tema</h4><p>Claro, oscuro o según tu dispositivo.</p></div><div class="segmented">${['system','light','dark'].map(t=>`<button data-theme-choice="${t}" class="${theme===t?'active':''}">${t==='system'?'Auto':t==='light'?'Claro':'Oscuro'}</button>`).join('')}</div></div><div class="settings-row"><div><h4>Notificaciones</h4><p>Permite avisos cuando termine una sesión de enfoque.</p></div><button class="btn small" id="notifyBtn">Activar</button></div></div>
      <div class="card"><div class="card-header"><h2 class="card-title">Enfoque</h2></div><div class="form-grid"><div class="field"><label>Enfoque (min)</label><input id="focusMinutes" type="number" min="5" max="120" value="${fm}"></div><div class="field"><label>Descanso (min)</label><input id="shortBreak" type="number" min="1" max="60" value="${sb}"></div><div class="field full"><label>Descanso largo (min)</label><input id="longBreak" type="number" min="5" max="90" value="${lb}"></div></div><button class="btn primary" id="saveFocus" style="margin-top:14px">Guardar tiempos</button></div>
      <div class="card"><div class="card-header"><h2 class="card-title">Tus datos</h2></div><div class="settings-row"><div><h4>Base de datos local</h4><p>${count} registros guardados en IndexedDB. No requiere cuenta ni servidor.</p></div><span class="priority low">Activa</span></div><div class="settings-row"><div><h4>Exportar respaldo</h4><p>Descarga todos tus datos en un archivo JSON.</p></div><button class="btn small" id="exportData">Exportar</button></div><div class="settings-row"><div><h4>Importar respaldo</h4><p>Restaura un archivo exportado anteriormente.</p></div><button class="btn small" id="importData">Importar</button></div></div>
      <div class="card"><div class="card-header"><h2 class="card-title">Zona de riesgo</h2></div><div class="settings-row"><div><h4>Borrar todos los datos</h4><p>Elimina agenda, horario, recordatorios, mazos y sesiones.</p></div><button class="btn small danger" id="clearData">Borrar</button></div></div></div>`;
    $('#content').querySelectorAll('[data-theme-choice]').forEach(b=>b.onclick=async()=>{await setSetting('theme',b.dataset.themeChoice);await applyTheme();render()});$('#notifyBtn').onclick=async()=>{if(!('Notification'in window))return toast('Este navegador no admite notificaciones');const p=await Notification.requestPermission();toast(p==='granted'?'Notificaciones activadas':'No se concedió el permiso')};$('#saveFocus').onclick=async()=>{await setSetting('focusMinutes',Number($('#focusMinutes').value)||25);await setSetting('shortBreak',Number($('#shortBreak').value)||5);await setSetting('longBreak',Number($('#longBreak').value)||15);state.focus.initialized=false;toast('Tiempos guardados')};$('#exportData').onclick=exportData;$('#importData').onclick=importData;$('#clearData').onclick=()=>confirmModal('Borrar todos los datos','Esta acción no se puede deshacer. Exporta un respaldo antes si quieres conservarlos.',async()=>{for(const s of DB_STORES)await clearStore(s);state.studyDeck=null;state.focus.initialized=false;toast('Datos borrados');render()});
  }

  function modal(title,body,onSave,{saveText='Guardar',dangerText=null,onDanger=null}={}){
    $('#modalRoot').innerHTML=`<div class="modal-backdrop"><div class="modal" role="dialog" aria-modal="true"><div class="modal-head"><h2>${esc(title)}</h2><button class="icon-btn" data-close>×</button></div><div class="modal-body">${body}</div><div class="modal-foot">${dangerText?`<button class="btn danger" data-danger style="margin-right:auto">${esc(dangerText)}</button>`:''}<button class="btn" data-close>Cancelar</button><button class="btn primary" data-save>${esc(saveText)}</button></div></div></div>`;
    const root=$('#modalRoot');root.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>root.innerHTML='');root.querySelector('.modal-backdrop').onclick=e=>{if(e.target.classList.contains('modal-backdrop'))root.innerHTML=''};root.querySelector('[data-save]').onclick=async()=>{const ok=await onSave(root);if(ok!==false)root.innerHTML=''};if(onDanger)root.querySelector('[data-danger]').onclick=async()=>{await onDanger();root.innerHTML=''};setTimeout(()=>root.querySelector('input,select,textarea')?.focus(),0)
  }
  function confirmModal(title,text,onYes){modal(title,`<p class="subtle" style="font-size:13px;line-height:1.6">${esc(text)}</p>`,async()=>{await onYes()},{saveText:'Sí, continuar'})}
  function activityModal(a,date=state.selectedDate){
    modal(a?'Editar actividad':'Nueva actividad',`<div class="form-grid"><div class="field full"><label>Título</label><input id="fTitle" value="${esc(a?.title||'')}" placeholder="Ej. Entregar tarea de IA"></div><div class="field"><label>Fecha</label><input id="fDate" type="date" value="${a?.date||date}"></div><div class="field"><label>Hora</label><input id="fTime" type="time" value="${a?.time||''}"></div><div class="field"><label>Prioridad</label><select id="fPriority"><option value="low" ${a?.priority==='low'?'selected':''}>Baja</option><option value="medium" ${!a?.priority||a?.priority==='medium'?'selected':''}>Media</option><option value="high" ${a?.priority==='high'?'selected':''}>Alta</option></select></div><div class="field"><label>Estado</label><select id="fDone"><option value="false">Pendiente</option><option value="true" ${a?.done?'selected':''}>Completada</option></select></div><div class="field full"><label>Notas</label><textarea id="fNotes" placeholder="Detalles opcionales">${esc(a?.notes||'')}</textarea></div></div>`,async r=>{const title=r.querySelector('#fTitle').value.trim();if(!title){toast('Escribe un título');return false}await put('activities',{id:a?.id||uid(),title,date:r.querySelector('#fDate').value,time:r.querySelector('#fTime').value,priority:r.querySelector('#fPriority').value,done:r.querySelector('#fDone').value==='true',notes:r.querySelector('#fNotes').value.trim(),createdAt:a?.createdAt||Date.now()});toast('Actividad guardada');render()},{dangerText:a?'Eliminar':null,onDanger:a?async()=>{await del('activities',a.id);toast('Actividad eliminada');render()}:null})
  }
  function reminderModal(r){
    modal(r?'Editar recordatorio':'Nuevo recordatorio',`<div class="form-grid"><div class="field full"><label>Recordatorio</label><input id="rTitle" value="${esc(r?.title||'')}" placeholder="Ej. Pagar inscripción"></div><div class="field"><label>Fecha</label><input id="rDate" type="date" value="${r?.date||state.selectedDate}"></div><div class="field"><label>Hora</label><input id="rTime" type="time" value="${r?.time||''}"></div><div class="field"><label>Prioridad</label><select id="rPriority"><option value="low" ${r?.priority==='low'?'selected':''}>Baja</option><option value="medium" ${!r?.priority||r?.priority==='medium'?'selected':''}>Media</option><option value="high" ${r?.priority==='high'?'selected':''}>Alta</option></select></div><div class="field"><label>Estado</label><select id="rDone"><option value="false">Pendiente</option><option value="true" ${r?.done?'selected':''}>Completado</option></select></div><div class="field full"><label>Notas</label><textarea id="rNotes">${esc(r?.notes||'')}</textarea></div></div>`,async root=>{const title=root.querySelector('#rTitle').value.trim();if(!title){toast('Escribe el recordatorio');return false}await put('reminders',{id:r?.id||uid(),title,date:root.querySelector('#rDate').value,time:root.querySelector('#rTime').value,priority:root.querySelector('#rPriority').value,done:root.querySelector('#rDone').value==='true',notes:root.querySelector('#rNotes').value.trim(),createdAt:r?.createdAt||Date.now()});toast('Recordatorio guardado');render()},{dangerText:r?'Eliminar':null,onDanger:r?async()=>{await del('reminders',r.id);render()}:null})
  }
  function scheduleModal(b){
    const dayOptions=[1,2,3,4,5,6,0].map(d=>`<option value="${d}" ${Number(b?.day)===d?'selected':''}>${DAYS[d]}</option>`).join('');
    modal(b?'Editar bloque':'Nuevo bloque semanal',`<div class="form-grid"><div class="field full"><label>Nombre</label><input id="sTitle" value="${esc(b?.title||'')}" placeholder="Ej. Inglés B1"></div><div class="field"><label>Día</label><select id="sDay">${dayOptions}</select></div><div class="field"><label>Lugar</label><input id="sLocation" value="${esc(b?.location||'')}" placeholder="Aula / oficina"></div><div class="field"><label>Inicio</label><input id="sStart" type="time" value="${b?.start||'08:00'}"></div><div class="field"><label>Fin</label><input id="sEnd" type="time" value="${b?.end||'09:00'}"></div></div>`,async root=>{const title=root.querySelector('#sTitle').value.trim(),start=root.querySelector('#sStart').value,end=root.querySelector('#sEnd').value;if(!title){toast('Escribe un nombre');return false}if(end<=start){toast('La hora final debe ser posterior');return false}await put('schedule',{id:b?.id||uid(),title,day:Number(root.querySelector('#sDay').value),start,end,location:root.querySelector('#sLocation').value.trim()});toast('Horario guardado');render()},{dangerText:b?'Eliminar':null,onDanger:b?async()=>{await del('schedule',b.id);render()}:null})
  }
  function deckModal(d){modal(d?'Editar mazo':'Nuevo mazo',`<div class="form-grid"><div class="field"><label>Icono</label><input id="dIcon" maxlength="3" value="${esc(d?.icon||'✦')}"></div><div class="field"><label>Nombre</label><input id="dName" value="${esc(d?.name||'')}" placeholder="Ej. Fundamentos de IA"></div><div class="field full"><label>Descripción</label><textarea id="dDesc" placeholder="¿Qué vas a estudiar?">${esc(d?.description||'')}</textarea></div></div>`,async root=>{const name=root.querySelector('#dName').value.trim();if(!name){toast('Ponle un nombre al mazo');return false}const id=d?.id||uid();await put('decks',{id,name,icon:root.querySelector('#dIcon').value.trim()||'✦',description:root.querySelector('#dDesc').value.trim(),createdAt:d?.createdAt||Date.now()});state.studyDeck=id;toast('Mazo guardado');render()},{dangerText:d?'Eliminar mazo':null,onDanger:d?async()=>{const cs=(await getAll('cards')).filter(c=>c.deckId===d.id);for(const c of cs)await del('cards',c.id);await del('decks',d.id);state.studyDeck=null;render()}:null})}
  function cardModal(deckId,c){modal(c?'Editar tarjeta':'Nueva tarjeta',`<div class="form-grid"><div class="field full"><label>Frente · pregunta o concepto</label><textarea id="cFront" placeholder="Ej. ¿Qué es aprendizaje automático?">${esc(c?.front||'')}</textarea></div><div class="field full"><label>Reverso · respuesta</label><textarea id="cBack" placeholder="Escribe la respuesta">${esc(c?.back||'')}</textarea></div></div>`,async root=>{const front=root.querySelector('#cFront').value.trim(),back=root.querySelector('#cBack').value.trim();if(!front||!back){toast('Completa ambos lados');return false}await put('cards',{id:c?.id||uid(),deckId,front,back,createdAt:c?.createdAt||Date.now()});toast('Tarjeta guardada');render()},{dangerText:c?'Eliminar':null,onDanger:c?async()=>{await del('cards',c.id);render()}:null})}

  async function exportData(){const out={version:1,exportedAt:new Date().toISOString(),data:{}};for(const s of DB_STORES)out.data[s]=await getAll(s);const blob=new Blob([JSON.stringify(out,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`mi-ritmo-respaldo-${isoDate(new Date())}.json`;a.click();URL.revokeObjectURL(url);toast('Respaldo exportado')}
  function importData(){const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.onchange=async()=>{try{const obj=JSON.parse(await input.files[0].text());if(!obj.data)throw new Error('Formato inválido');for(const s of DB_STORES){if(Array.isArray(obj.data[s]))for(const row of obj.data[s])await put(s,row)}toast('Respaldo importado');await applyTheme();render()}catch(e){toast('No se pudo importar el archivo')}};input.click()}
  function toast(msg){const t=document.createElement('div');t.className='toast';t.textContent=msg;$('#toastRoot').appendChild(t);setTimeout(()=>t.remove(),2800)}

  init().catch(err=>{console.error(err);document.body.innerHTML='<main style="font-family:system-ui;padding:40px"><h1>Mi Ritmo</h1><p>No se pudo iniciar la base de datos local. Prueba en un navegador moderno sin modo privado.</p></main>'});
})();
